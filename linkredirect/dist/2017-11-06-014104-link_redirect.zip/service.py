# -*- coding: utf-8 -*-
"""Module that implements a link redirect engine for url shortener"""
import json
import boto3
import certifi
from elasticsearch import Elasticsearch, RequestsHttpConnection
from aws_requests_auth.aws_auth import AWSRequestsAuth


def handler(event, context):
    """Event handler in lambda context"""
    url = event["params"]["path"]["shorturl"]
    client = boto3.client("dynamodb")
    esEndPoint = "https://search-url-shortener-t76w2u5nrhzsacc3n2oy3lvozi.us-west-1.es.amazonaws.com"

    try:
        item = client.get_item(TableName="urls", Key={
            "shorturl" : {"S":url}
        })
    except Exception, exception:
        return exception

    session = boto3.session.Session()
    credentials = session.get_credentials().get_frozen_credentials()
    awsauth = AWSRequestsAuth(
        aws_access_key=credentials.access_key,
        aws_secret_access_key=credentials.secret_key,
        aws_token=credentials.token,
        aws_host=esEndPoint,
        aws_region=session.region_name,
        aws_service='es'
    )
    esClient = Elasticsearch(
        hosts=[{'host': esEndPoint, 'port': 443}],
        http_auth=awsauth,
        use_ssl=True,
        verify_certs=True,
        ca_certs=certifi.where(),
        connection_class=RequestsHttpConnection
        )
    esClient.index(index="urls", doc_type="hit", body=json.dumps(event))

    return {"Location":"http://"+item["Item"]["url"]["S"]}
