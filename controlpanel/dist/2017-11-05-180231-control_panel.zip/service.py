# -*- coding: utf-8 -*-
"""Module that implements a control panel for url shortener"""
import uuid
import boto3


def handler(event, context):
    """Even handler in lambda context"""
    url = event["url"]
    if url.startswith("http://"):
        url = url[7:]
    if url.startswith("https://"):
        url = url[8:]

    client = boto3.client("dynamodb")
    item = {"url":url, "shorturl":str(uuid.uuid4().hex)}
    try:
        client.put.item(TableName="urls", Item=item)
    except Exception, exception:
        return 400, exception

    #print("short"+short)
    return 200, "OK", item
